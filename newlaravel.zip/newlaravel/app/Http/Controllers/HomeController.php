<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use File;
use Twitter;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        
        $twitter_user_info = null;
        
        try {
            $twitter_user_info = collect(Twitter::getCredentials(['include_email' => 'true']))->toArray();
        } catch (\Exception $e) {}
        
        return view('home', ['twitter_user_info' => $twitter_user_info]);
    }
    
    public function upload_media_file (Request $request)
    {
        
        $request->validate([
            'description' => 'required',
            'media_file' => 'required|mimes:jpeg,png,jpg,gif,svg,mp4|max:10240',
        ]);
        
        $description = $request->input('description');
        $media_file = $request->media_file;
        
        $media_file_name = time() . '.'.$media_file->extension();
        
        $media_file->move(public_path('media_files'), $media_file_name);
        
        // Redirect Back to the prev page with success
        return back()
            ->with('success', 'You have successfully upload your media file.')
            ->with('media_file_description', $description)
            ->with('media_file_name', $media_file_name);
        
        return ;
    }
    
    public function post_tweet (Request $request)
    {
        
        $request->validate([
            'status' => 'required',
            'media_file_name' => 'required',
        ]);
        
        $status = $request->input('status');
        $media_file_name = $request->input('media_file_name');
        
        try {
            $uploaded_media = Twitter::uploadMedia(['media' => File::get(public_path('media_files/' . $media_file_name))]);
            $tweet_posted = collect(Twitter::postTweet(['status' => $status, 'media_ids' => $uploaded_media->media_id_string]));        
            return response()->json($tweet_posted);
        } catch (\Exception $e) {
            return  response()->json(['error' => $e->getMessage()]);
        }
    }
}
