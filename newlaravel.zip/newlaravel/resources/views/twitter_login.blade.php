<div class="card">
    
    <div class="card-header">Twitter Login</div>
    
    <div class="card-body">
        
        <p>You have to login via twitter to be able to upload your media</p>
        
        <a class="btn btn-primary" href="{{ route('twitter_login') }}">Twitter Login</a>
        
    </div>
</div>