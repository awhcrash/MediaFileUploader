@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            @if ($twitter_user_info == null)
            @include('twitter_login')
            @else
            @include('upload_media')
            @endif
            
        </div>
    </div>
</div>
@endsection
