<?php if(session('success')): ?>
<div class="card mb-5">
    <div class="card-header">Your Uploaded Media File</div>

    <div class="card-body">

        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        
        <div>

            <div class="mb-3">
                <label for="media_file_link" class="form-label">Your Media File link</label>
                <input type="text" class="form-control" id="media_file_link" value="http://localhost/newlaravel/public/media_files/<?php echo e(session('media_file_name')); ?>" readonly>
            </div>

            <div class="text-center mb-3">
                <img width="256" src="http://localhost/newlaravel/public/media_files/<?php echo e(session('media_file_name')); ?>" class="rounded mb-3">
            
                <button type="button" onclick="postTweet();" class="btn btn-primary" id="post-tweet-button">Post Tweet to My account</button>
            </div>
            
            <script>

                function postTweet () {
                    $('#post-tweet-button').attr('disabled', 'disabled');
                    $.post("<?php echo e(route('post_tweet')); ?>", {
                        status : "<?php echo e(session('media_file_description')); ?>", media_file_name: "<?php echo e(session('media_file_name')); ?>", _token:'<?php echo e(csrf_token()); ?>'
                    }, function (response) {
                        if ('error' in response) {
                            alert(response.error);
                            $('#post-tweet-button').removeAttr('disabled')
                        } else alert('Your uploaded media file has been tweeted on your account!');
                    });
                }
            </script>

        </div>

    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">Upload Your Media File</div>

    <div class="card-body">

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <div class="alert alert-info">
            File extensions allowed: (jpeg,png,jpg,gif,svg,mp4)
        </div>

        <form method="post" action="<?php echo e(route('upload_media_file')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="description" class="form-label">Media File Description</label>
                <input type="text" class="form-control" id="description" name="description">
            </div>

            <div class="mb-3">
                <label for="media_file" class="form-label">Please select a Media File</label>
                <input class="form-control" type="file" id="media_file" name="media_file">
            </div>

            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/newlaravel/resources/views/uploading_media.blade.php ENDPATH**/ ?>