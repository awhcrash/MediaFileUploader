<div class="card">
    
    <div class="card-header">Twitter Login</div>
    
    <div class="card-body">
        
        <p>You have to login via twitter to be able to upload your media</p>
        
        <a class="btn btn-primary" href="<?php echo e(route('twitter_login')); ?>">Twitter Login</a>
        
    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/newlaravel/resources/views/twitter_login.blade.php ENDPATH**/ ?>